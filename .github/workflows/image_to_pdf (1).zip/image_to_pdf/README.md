# Image to PDF (Offline, Ad-Free)

Converts images to PDF entirely on the device. No internet permission, no ads, no analytics, no account.

## What the app does

- Pick several images from the gallery, or take a photo with the camera
- Reorder pages by dragging, rotate, crop, remove
- Choose page size (A4, Letter, fit to image), orientation, margin, image quality and file name
- Create the PDF, preview it, share or save it through the system share sheet
- "My PDFs" list inside the app to reopen, share or delete earlier files

## Setup, step by step

1. Install Flutter (https://docs.flutter.dev/get-started/install) and run `flutter doctor` until Android (and Xcode, if you want iOS) show no problems.
2. Put this folder somewhere and open a terminal inside it.
3. Generate the Android and iOS folders:

       flutter create --org com.bravo --project-name image_to_pdf .

   When asked about existing files, keep `pubspec.yaml` and the `lib` folder as they are. If `flutter create` overwrites `pubspec.yaml`, copy the dependencies from the version in this project back in.
4. Apply the permission settings (camera and photo text for iOS, the crop screen for Android, and removal of the internet permission from the main manifest):

       python3 tools/apply_platform_config.py

5. Download the packages:

       flutter pub get

6. Check the code:

       flutter analyze

7. Run on a phone or emulator:

       flutter run

8. Build the release app:

       flutter build apk --release

   The file is `build/app/outputs/flutter-apk/app-release.apk`.

## Build the APK on GitHub (no Flutter needed on your computer)

1. Create a new repository on github.com.
2. Upload everything in this folder to it, including the hidden `.github` folder. On the website: Add file, Upload files, then drag the whole folder contents in. Make sure the branch is called `main`.
3. Open the Actions tab. The "Build APK" workflow starts by itself after the upload. You can also start it with Run workflow.
4. Wait about 5 to 10 minutes until the run shows a green tick.
5. Open the finished run and download `image-to-pdf-apk` from the Artifacts section. Unzip it to get `app-release.apk`.
6. Copy the APK to your phone and open it. Android will ask you to allow installing from this source.

The APK is signed with a debug key, which is fine for testing and sharing directly. A Play Store release needs your own signing key.

## Confirm it is really offline

Flutter's debug and profile builds add the internet permission so hot reload works. Release builds do not have it. To confirm:

    aapt dump permissions build/app/outputs/flutter-apk/app-release.apk

The list must not contain `android.permission.INTERNET`.

## Project layout

    lib/main.dart                      app theme and entry point
    lib/models/models.dart             page, options and quality definitions
    lib/services/image_service.dart    gallery, camera and crop
    lib/services/pdf_service.dart      rotate, resize, compress and build the PDF
    lib/services/storage_service.dart  save, list, delete and share PDFs
    lib/screens/                       home, editor, options, viewer, library

## Known limits of this first version

- Crop shows the picture in its original direction. If you rotate and crop the same page, crop first, then rotate.
- Camera capture uses the phone's camera app, then the crop screen. There is no automatic edge detection yet.
- Not included yet: password protection, merge and split, compress an existing PDF, PDF to image.
