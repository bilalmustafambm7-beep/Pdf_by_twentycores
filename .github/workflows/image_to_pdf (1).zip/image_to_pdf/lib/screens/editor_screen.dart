import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/models.dart';
import '../services/image_service.dart';
import '../services/pdf_service.dart';
import '../services/storage_service.dart';
import 'options_sheet.dart';
import 'viewer_screen.dart';

class EditorScreen extends StatefulWidget {
  const EditorScreen({super.key, required this.initialPages});

  final List<PageItem> initialPages;

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  late final List<PageItem> _pages = List.of(widget.initialPages);
  final PdfOptions _options = PdfOptions();
  bool _working = false;
  double _progress = 0;

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _add(Future<List<PageItem>> Function() source) async {
    try {
      final items = await source();
      if (items.isEmpty || !mounted) return;
      setState(() => _pages.addAll(items));
    } catch (e) {
      _message('Could not add images.');
    }
  }

  Future<void> _crop(int index) async {
    try {
      final result = await ImageService.crop(_pages[index].path);
      if (result == null || !mounted) return;
      setState(() => _pages[index].path = result);
    } catch (e) {
      _message('Could not crop this image.');
    }
  }

  void _rotate(int index) {
    setState(() {
      final page = _pages[index];
      page.quarterTurns = (page.quarterTurns + 1) % 4;
    });
  }

  void _remove(int index) {
    setState(() => _pages.removeAt(index));
    if (_pages.isEmpty) Navigator.pop(context);
  }

  void _reorder(int oldIndex, int newIndex) {
    setState(() {
      if (newIndex > oldIndex) newIndex -= 1;
      final item = _pages.removeAt(oldIndex);
      _pages.insert(newIndex, item);
    });
  }

  Future<void> _openOptions() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => OptionsSheet(options: _options),
    );
    if (mounted) setState(() {});
  }

  Future<void> _create() async {
    if (_pages.isEmpty || _working) return;
    setState(() {
      _working = true;
      _progress = 0;
    });
    try {
      final bytes = await PdfService.build(
        _pages,
        _options,
        onProgress: (done, total) {
          if (mounted) setState(() => _progress = done / total);
        },
      );
      final file = await StorageService.save(bytes, _options.fileName);
      if (!mounted) return;
      await Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => ViewerScreen(file: file)),
      );
    } on FormatException catch (e) {
      _message(e.message);
    } catch (e) {
      _message('Could not create the PDF. Try a smaller quality setting.');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final count = _pages.length;
    return Scaffold(
      appBar: AppBar(
        title: Text(count == 1 ? '1 page' : '$count pages'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.add),
            tooltip: 'Add pages',
            enabled: !_working,
            onSelected: (value) => _add(
              value == 'camera'
                  ? ImageService.fromCamera
                  : ImageService.fromGallery,
            ),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'gallery', child: Text('From gallery')),
              PopupMenuItem(value: 'camera', child: Text('Take a photo')),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'PDF options',
            onPressed: _working ? null : _openOptions,
          ),
        ],
        bottom: _working
            ? PreferredSize(
                preferredSize: const Size.fromHeight(3),
                child: LinearProgressIndicator(value: _progress),
              )
            : null,
      ),
      body: ReorderableListView.builder(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
        buildDefaultDragHandles: false,
        itemCount: count,
        onReorder: _reorder,
        itemBuilder: (context, index) {
          final page = _pages[index];
          return Card(
            key: ObjectKey(page),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: SizedBox(
                      width: 72,
                      height: 72,
                      child: Transform.rotate(
                        angle: page.quarterTurns * math.pi / 2,
                        child: Image.file(
                          File(page.path),
                          fit: BoxFit.cover,
                          cacheWidth: 240,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Page ${index + 1}',
                      style: Theme.of(context).textTheme.titleSmall,
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.rotate_right),
                    tooltip: 'Rotate',
                    onPressed: _working ? null : () => _rotate(index),
                  ),
                  IconButton(
                    icon: const Icon(Icons.crop),
                    tooltip: 'Crop',
                    onPressed: _working ? null : () => _crop(index),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline),
                    tooltip: 'Remove',
                    onPressed: _working ? null : () => _remove(index),
                  ),
                  ReorderableDragStartListener(
                    index: index,
                    child: const Padding(
                      padding: EdgeInsets.all(6),
                      child: Icon(Icons.drag_handle, color: Colors.black45),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: FilledButton(
            onPressed: _working ? null : _create,
            child: Text(_working ? 'Creating PDF...' : 'Create PDF'),
          ),
        ),
      ),
    );
  }
}
