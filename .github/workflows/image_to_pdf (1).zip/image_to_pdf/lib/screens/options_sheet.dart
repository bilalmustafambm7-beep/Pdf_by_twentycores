import 'package:flutter/material.dart';

import '../models/models.dart';

class OptionsSheet extends StatefulWidget {
  const OptionsSheet({super.key, required this.options});

  final PdfOptions options;

  @override
  State<OptionsSheet> createState() => _OptionsSheetState();
}

class _OptionsSheetState extends State<OptionsSheet> {
  late final TextEditingController _name =
      TextEditingController(text: widget.options.fileName);

  PdfOptions get _o => widget.options;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w600)),
      );

  @override
  Widget build(BuildContext context) {
    final fit = _o.pageSize == PageSizeOption.fit;
    return Padding(
      padding: EdgeInsets.fromLTRB(
        20,
        0,
        20,
        MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'PDF options',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            _label('File name'),
            TextField(
              controller: _name,
              onChanged: (v) => _o.fileName = v,
              decoration: const InputDecoration(
                hintText: 'Leave empty for an automatic name',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
            _label('Page size'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<PageSizeOption>(
                segments: const [
                  ButtonSegment(value: PageSizeOption.a4, label: Text('A4')),
                  ButtonSegment(
                      value: PageSizeOption.letter, label: Text('Letter')),
                  ButtonSegment(
                      value: PageSizeOption.fit, label: Text('Fit image')),
                ],
                selected: {_o.pageSize},
                onSelectionChanged: (s) =>
                    setState(() => _o.pageSize = s.first),
              ),
            ),
            _label('Orientation'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<OrientationOption>(
                segments: const [
                  ButtonSegment(
                      value: OrientationOption.auto, label: Text('Auto')),
                  ButtonSegment(
                      value: OrientationOption.portrait,
                      label: Text('Portrait')),
                  ButtonSegment(
                      value: OrientationOption.landscape,
                      label: Text('Landscape')),
                ],
                selected: {_o.orientation},
                onSelectionChanged: fit
                    ? null
                    : (s) => setState(() => _o.orientation = s.first),
              ),
            ),
            _label('Image quality'),
            SizedBox(
              width: double.infinity,
              child: SegmentedButton<QualityOption>(
                segments: [
                  for (final q in QualityOption.values)
                    ButtonSegment(value: q, label: Text(q.label)),
                ],
                selected: {_o.quality},
                onSelectionChanged: (s) => setState(() => _o.quality = s.first),
              ),
            ),
            _label('Margin: ${_o.marginMm.round()} mm'),
            Slider(
              value: _o.marginMm,
              min: 0,
              max: 25,
              divisions: 25,
              onChanged: (v) => setState(() => _o.marginMm = v),
            ),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Done'),
            ),
          ],
        ),
      ),
    );
  }
}
