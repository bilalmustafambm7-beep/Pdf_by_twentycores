import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:printing/printing.dart';

import '../services/storage_service.dart';

class ViewerScreen extends StatelessWidget {
  const ViewerScreen({super.key, required this.file});

  final File file;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          p.basename(file.path),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.ios_share),
            tooltip: 'Share or save',
            onPressed: () => StorageService.share(file),
          ),
        ],
      ),
      body: PdfPreview(
        build: (_) => file.readAsBytes(),
        useActions: false,
        canChangeOrientation: false,
        canChangePageFormat: false,
        canDebug: false,
        pdfFileName: p.basename(file.path),
      ),
    );
  }
}
