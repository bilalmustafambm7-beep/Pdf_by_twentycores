import 'package:flutter/material.dart';

import 'screens/home_screen.dart';

void main() {
  runApp(const ImageToPdfApp());
}

class ImageToPdfApp extends StatelessWidget {
  const ImageToPdfApp({super.key});

  @override
  Widget build(BuildContext context) {
    const ink = Color(0xFF1B2A41);
    final scheme = ColorScheme.fromSeed(
      seedColor: ink,
      brightness: Brightness.light,
    ).copyWith(primary: ink, surface: Colors.white);

    return MaterialApp(
      title: 'Image to PDF',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFFF6F6F4),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFF6F6F4),
          foregroundColor: ink,
          elevation: 0,
          scrolledUnderElevation: 0,
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10),
            side: const BorderSide(color: Color(0xFFE2E2DE)),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            foregroundColor: ink,
            side: const BorderSide(color: Color(0xFFC9C9C4)),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}
