enum PageSizeOption { a4, letter, fit }

enum OrientationOption { auto, portrait, landscape }

enum QualityOption {
  low('Small file', 60, 1280),
  medium('Balanced', 80, 1800),
  high('High quality', 92, 2800);

  const QualityOption(this.label, this.jpegQuality, this.maxSide);

  final String label;
  final int jpegQuality;
  final int maxSide;
}

class PageItem {
  PageItem(this.path);

  String path;
  int quarterTurns = 0;
}

class PdfOptions {
  PageSizeOption pageSize = PageSizeOption.a4;
  OrientationOption orientation = OrientationOption.auto;
  QualityOption quality = QualityOption.medium;
  double marginMm = 8;
  String fileName = '';
}
