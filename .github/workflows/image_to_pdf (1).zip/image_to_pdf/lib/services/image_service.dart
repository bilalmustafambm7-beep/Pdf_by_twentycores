import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';

import '../models/models.dart';

class ImageService {
  static final ImagePicker _picker = ImagePicker();

  static Future<List<PageItem>> fromGallery() async {
    final files = await _picker.pickMultiImage();
    return files.map((f) => PageItem(f.path)).toList();
  }

  static Future<List<PageItem>> fromCamera() async {
    final file = await _picker.pickImage(source: ImageSource.camera);
    if (file == null) return [];
    return [PageItem(file.path)];
  }

  static Future<String?> crop(String path) async {
    final result = await ImageCropper().cropImage(
      sourcePath: path,
      uiSettings: [
        AndroidUiSettings(
          toolbarTitle: 'Crop',
          lockAspectRatio: false,
          initAspectRatio: CropAspectRatioPreset.original,
        ),
        IOSUiSettings(title: 'Crop'),
      ],
    );
    return result?.path;
  }
}
