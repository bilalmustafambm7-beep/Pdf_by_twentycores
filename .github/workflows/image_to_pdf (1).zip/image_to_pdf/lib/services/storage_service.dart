import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

class StorageService {
  static Future<Directory> _folder() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'PDFs'));
    if (!await dir.exists()) {
      await dir.create(recursive: true);
    }
    return dir;
  }

  static String _clean(String name) {
    var value = name.trim().replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    if (value.toLowerCase().endsWith('.pdf')) {
      value = value.substring(0, value.length - 4).trim();
    }
    return value;
  }

  static String defaultName() {
    final d = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    return 'PDF_${d.year}${two(d.month)}${two(d.day)}_'
        '${two(d.hour)}${two(d.minute)}${two(d.second)}';
  }

  static Future<File> save(Uint8List bytes, String requestedName) async {
    final dir = await _folder();
    var base = _clean(requestedName);
    if (base.isEmpty) base = defaultName();
    var file = File(p.join(dir.path, '$base.pdf'));
    var count = 1;
    while (await file.exists()) {
      file = File(p.join(dir.path, '$base ($count).pdf'));
      count++;
    }
    return file.writeAsBytes(bytes, flush: true);
  }

  static Future<List<File>> list() async {
    final dir = await _folder();
    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.pdf'))
        .toList();
    files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    return files;
  }

  static Future<void> delete(File file) async {
    await file.delete();
  }

  static Future<void> share(File file) async {
    await Share.shareXFiles([XFile(file.path)]);
  }

  static String prettySize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
    return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
  }

  static String prettyDate(DateTime d) {
    String two(int v) => v.toString().padLeft(2, '0');
    return '${two(d.day)}/${two(d.month)}/${d.year}  ${two(d.hour)}:${two(d.minute)}';
  }
}
