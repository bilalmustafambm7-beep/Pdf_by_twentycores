import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/models.dart';

class _PrepareJob {
  const _PrepareJob(this.path, this.quarterTurns, this.maxSide, this.jpegQuality);

  final String path;
  final int quarterTurns;
  final int maxSide;
  final int jpegQuality;
}

class _PreparedImage {
  const _PreparedImage(this.bytes, this.width, this.height);

  final Uint8List bytes;
  final int width;
  final int height;
}

_PreparedImage _prepareImage(_PrepareJob job) {
  final source = img.decodeImage(File(job.path).readAsBytesSync());
  if (source == null) {
    throw const FormatException('This image format is not supported.');
  }
  var image = img.bakeOrientation(source);
  final turns = job.quarterTurns % 4;
  if (turns != 0) {
    image = img.copyRotate(image, angle: turns * 90);
  }
  final longest = math.max(image.width, image.height);
  if (longest > job.maxSide) {
    final scale = job.maxSide / longest;
    image = img.copyResize(
      image,
      width: (image.width * scale).round(),
      height: (image.height * scale).round(),
    );
  }
  final bytes = Uint8List.fromList(img.encodeJpg(image, quality: job.jpegQuality));
  return _PreparedImage(bytes, image.width, image.height);
}

class PdfService {
  static Future<Uint8List> build(
    List<PageItem> pages,
    PdfOptions options, {
    void Function(int done, int total)? onProgress,
  }) async {
    final doc = pw.Document(creator: 'Image to PDF');
    final margin = options.marginMm * PdfPageFormat.mm;

    for (var i = 0; i < pages.length; i++) {
      final item = pages[i];
      final prepared = await compute(
        _prepareImage,
        _PrepareJob(
          item.path,
          item.quarterTurns,
          options.quality.maxSide,
          options.quality.jpegQuality,
        ),
      );
      final image = pw.MemoryImage(prepared.bytes);
      doc.addPage(
        pw.Page(
          pageFormat: _format(prepared, options, margin),
          margin: pw.EdgeInsets.all(margin),
          build: (_) => pw.Center(
            child: pw.Image(image, fit: pw.BoxFit.contain),
          ),
        ),
      );
      onProgress?.call(i + 1, pages.length);
    }
    return doc.save();
  }

  static PdfPageFormat _format(
    _PreparedImage image,
    PdfOptions options,
    double margin,
  ) {
    if (options.pageSize == PageSizeOption.fit) {
      const pointsPerPixel = 72 / 150;
      return PdfPageFormat(
        image.width * pointsPerPixel + margin * 2,
        image.height * pointsPerPixel + margin * 2,
      );
    }
    final base = options.pageSize == PageSizeOption.a4
        ? PdfPageFormat.a4
        : PdfPageFormat.letter;
    switch (options.orientation) {
      case OrientationOption.portrait:
        return base.portrait;
      case OrientationOption.landscape:
        return base.landscape;
      case OrientationOption.auto:
        return image.width > image.height ? base.landscape : base.portrait;
    }
  }
}
