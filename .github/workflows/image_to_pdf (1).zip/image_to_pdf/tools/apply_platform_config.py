import pathlib
import re
import sys

manifest_path = pathlib.Path("android/app/src/main/AndroidManifest.xml")
plist_path = pathlib.Path("ios/Runner/Info.plist")

if not manifest_path.exists() or not plist_path.exists():
    sys.exit("Run this from the project root after running 'flutter create .' first.")

manifest = manifest_path.read_text(encoding="utf-8")

manifest = re.sub(
    r'\s*<uses-permission android:name="android\.permission\.INTERNET"\s*/>',
    "",
    manifest,
)

if "UCropActivity" not in manifest:
    crop_activity = (
        '    <activity\n'
        '        android:name="com.yalantis.ucrop.UCropActivity"\n'
        '        android:screenOrientation="portrait"\n'
        '        android:theme="@style/Theme.AppCompat.Light.NoActionBar"/>\n'
        '    '
    )
    manifest = manifest.replace("</application>", crop_activity + "</application>", 1)

manifest = re.sub(
    r'android:label="[^"]*"', 'android:label="Image to PDF"', manifest, count=1
)
manifest_path.write_text(manifest, encoding="utf-8")

plist = plist_path.read_text(encoding="utf-8")
keys = {
    "NSPhotoLibraryUsageDescription": "Choose images from your library to turn into a PDF. Images never leave your device.",
    "NSCameraUsageDescription": "Take photos of documents to turn into a PDF. Photos never leave your device.",
}
additions = ""
for key, text in keys.items():
    if key not in plist:
        additions += f"\t<key>{key}</key>\n\t<string>{text}</string>\n"
if additions:
    index = plist.rfind("</dict>")
    plist = plist[:index] + additions + plist[index:]
plist_path.write_text(plist, encoding="utf-8")

print("Platform configuration applied.")
